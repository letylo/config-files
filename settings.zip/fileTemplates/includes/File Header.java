/**
 * 
 * Copyright (C) 2019 Deveryware S.A. All Rights Reserved.
 *
 */